﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace projet1.Models
{
    public class EmployeeDetail : INotifyPropertyChanged

    {

        private string iD;

        private string name;

        private string age;

        private string gender;

        private string address;



        public string ID

        {

            get => iD; set

            {

                iD = value;

                OnPropertyChanged(nameof(ID));

            }

        }

        public string Name
        {
            get => name; set
            {

                name = value;

                OnPropertyChanged(nameof(Name));

            }

        }

        public string Age
        {
            get => age; set
            {

                age = value;

                OnPropertyChanged(nameof(Age));

            }

        }

        public string Gender
        {
            get => gender; set
            {

                gender = value;

                OnPropertyChanged(nameof(Gender));

            }

        }

        public string Address
        {
            get => address; set
            {

                address = value;

                OnPropertyChanged(nameof(Address));

            }

        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)

        {

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));

        }

    }
}

