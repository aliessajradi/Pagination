﻿using projet1.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Input;

namespace projet1.Business
{
    public class EmployeeViewModel : INotifyPropertyChanged
    {
        public EmployeeViewModel()
        {
            EmployeeCollection = CollectionViewSource.GetDefaultView(LstEmployeeDetail);

            #region Pagination
            NextCommand = new Command((s) => true, NextPage);
            FirstCommand = new Command((s) => true, FirstPage);
            LastCommand = new Command((s) => true, LastPage);
            PreviousCommand = new Command((s) => true, PreviousPage);
            #endregion
            LoadEmployee();


        }
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        private ICollectionView _employeeCollection;

        public ICollectionView EmployeeCollection
        {
            get { return _employeeCollection; }
            set
            {
                _employeeCollection = value;
                OnPropertyChanged(nameof(EmployeeCollection));
            }
        }
        private ObservableCollection<EmployeeDetail> _lstEmployeeDetail = new ObservableCollection<EmployeeDetail>();

        public ObservableCollection<EmployeeDetail> LstEmployeeDetail
        {
            get { return _lstEmployeeDetail; }
            set
            {
                _lstEmployeeDetail = value;
                OnPropertyChanged(nameof(LstEmployeeDetail));
            }
        }
        private void LoadEmployee()//Read details
        {
            
            for (int i = 0; i < 50; i++)
            { 
               
                var empDetails = new EmployeeDetail
                {
                    ID = $"{i+1}",
                    Name =$"MED_{i}",
                    Age = $"{i + 1}",
                    Gender = $"SES_{i}",
                    Address = $"RUE_AHMED_{i}"
                };
                LstOfRecords.Add(empDetails);
            }
            UpdateCollection(LstOfRecords.Take(SelectedRecord));
            UpdateRecordCount();

        }

        private void UpdateCollection(IEnumerable<EmployeeDetail> enumerable)
        {
            LstEmployeeDetail.Clear();
            foreach (var item in enumerable)
            {
                LstEmployeeDetail.Add(item);
            }
        }

        IEnumerable<string> ReadCSV(string filePath)
        {
            using (StreamReader reader = new StreamReader(filePath))
            {
                string line = string.Empty;
                while ((line = reader.ReadLine()) != null)
                {
                    var record = line.Trim();
                    if (!string.IsNullOrEmpty(record))
                        yield return record;
                }
            }
        }

        #region Pagination

        public ICommand FirstCommand { get; set; }
        public ICommand PreviousCommand { get; set; }
        public ICommand NextCommand { get; set; }
        public ICommand LastCommand { get; set; }

        private int _currentPage = 1;

        public int CurrentPage
        {
            get { return _currentPage; }
            set
            {
                _currentPage = value;
                OnPropertyChanged(nameof(CurrentPage));
                UpdateEnableState();
            }
        }

        private void UpdateEnableState()
        {
            IsFirstEnabled = CurrentPage > 1;
            IsPreviousEnabled = CurrentPage > 1;
            IsNextEnabled = CurrentPage < NumberOfPages;
            IsLastEnabled = CurrentPage < NumberOfPages;
        }

        private int _selectedRecord = 10;

        public int SelectedRecord
        {
            get { return _selectedRecord; }
            set
            {
                _selectedRecord = value;
                OnPropertyChanged(nameof(CurrentPage));
                UpdateRecordCount();
            }
        }

        private void UpdateRecordCount()
        {
            NumberOfPages = (int)Math.Ceiling((double)LstOfRecords.Count / SelectedRecord);
            NumberOfPages = NumberOfPages == 0 ? 1 : NumberOfPages;
            //UpdateCollection(LstOfRecords.Take(SelectedRecord));
            CurrentPage = 1;
        }

        private int _numberOfPages = 10;

        public int NumberOfPages
        {
            get { return _numberOfPages; }
            set
            {
                _numberOfPages = value;
                OnPropertyChanged(nameof(NumberOfPages));
                UpdateEnableState();
            }
        }
        private bool _isFirstEnabled;

        public bool IsFirstEnabled
        {
            get { return _isFirstEnabled; }
            set
            {
                _isFirstEnabled = value;
                OnPropertyChanged(nameof(IsFirstEnabled));
            }
        }
        private bool _isPreviousEnabled;

        public bool IsPreviousEnabled
        {
            get { return _isPreviousEnabled; }
            set
            {
                _isPreviousEnabled = value;
                OnPropertyChanged(nameof(IsPreviousEnabled));
            }
        }
        private bool _isNextEnabled;

        public bool IsNextEnabled
        {
            get { return _isNextEnabled; }
            set
            {
                _isNextEnabled = value;
                OnPropertyChanged(nameof(IsNextEnabled));
            }
        }
        private bool _isLastEnabled;

        public bool IsLastEnabled
        {
            get { return _isLastEnabled; }
            set
            {
                _isLastEnabled = value;
                OnPropertyChanged(nameof(IsLastEnabled));
            }
        }

        public List<EmployeeDetail> LstOfRecords { get; private set; } = new List<EmployeeDetail>();

        int RecordStartFrom = 0;
        private void PreviousPage(object obj)
        {
            CurrentPage--;
            RecordStartFrom = LstOfRecords.Count - SelectedRecord * (NumberOfPages - (CurrentPage - 1));
            var recorsToShow = LstOfRecords.Skip(RecordStartFrom).Take(SelectedRecord);
            UpdateCollection(recorsToShow);
            UpdateEnableState();
        }

        private void LastPage(object obj)
        {
            var recordsToskip = SelectedRecord * (NumberOfPages - 1);
            UpdateCollection(LstOfRecords.Skip(recordsToskip));
            CurrentPage = NumberOfPages;
            UpdateEnableState();
        }

        private void FirstPage(object obj)
        {
            UpdateCollection(LstOfRecords.Take(SelectedRecord));
            CurrentPage = 1;
            UpdateEnableState();
        }
        private void NextPage(object obj)
        {
            RecordStartFrom = CurrentPage * SelectedRecord;
            var recordsToShow = LstOfRecords.Skip(RecordStartFrom).Take(SelectedRecord);
            UpdateCollection(recordsToShow);
            CurrentPage++;
            UpdateEnableState();
        }

        #endregion
    }

    class Command : ICommand
    {
        public Command(Func<object, bool> methodCanExecute, Action<object> methodExecute)
        {
            MethodCanExecute = methodCanExecute;
            MethodExecute = methodExecute;
        }
        Action<object> MethodExecute;
        Func<object, bool> MethodCanExecute;
        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            return MethodExecute != null && MethodCanExecute.Invoke(parameter);
        }

        public void Execute(object parameter)
        {
            MethodExecute(parameter);
        }
    }
}

